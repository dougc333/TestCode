function img_out = transform_image_aa(img_in, T)
% Create an output image by applying the transformation T
% to img_in (a grayscale image), using inverse mapping and 
% trilinear interpolation
%
% Inputs
% ------
% img_in: the image to be transformed.  It is assumed to be 
%         in double format (e.g., intensities from 1-3).  It 
%         will have a single channel 
%      T: the affine transform to apply to the image.  T is a
%         3x3 matrix
%
% Outputs
% -------
% img_out: the transformed (grayscale) image.

[num_rows, num_cols] = size(img_in);

% TODO: Implement the rest of this function
