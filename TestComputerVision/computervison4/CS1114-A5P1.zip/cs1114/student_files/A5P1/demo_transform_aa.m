function demo_transform_aa()
% Function for demoing your image_transform_aa function
