function img_out = transform_image_rgb(img_in, T)
% Create an output image by applying the transformation T
% to img_in (an RGB image), using inverse mapping and 
% bilinear interpolation
