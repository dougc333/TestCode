function stack = create_image_stack(img, num_levels)
% Create an image stack from an image by repeated blurring.
%  num_levels is the number of images in the stack
