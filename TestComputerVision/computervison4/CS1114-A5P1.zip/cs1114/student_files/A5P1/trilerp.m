function value = trilerp(stack, row, col, level)
% Use trilinear interpolation to estimate the intensity of an image
% at the (real-valued) location row, col, level.
% Note: this function must call your bilerp and lerp functions.
