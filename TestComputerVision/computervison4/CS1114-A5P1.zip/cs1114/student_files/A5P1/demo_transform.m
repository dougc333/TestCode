function demo_transform()
% Function for demoing your image_transform function
