function value = lerp(v, x)
% Linear interpolation in one dimension
%
% Inputs
% ------
% v: a vector of data points
% x: a new position at which to compute the interpolated value
