function plot_convex_hull_performance()
%Generates plots comparing performance of convex hull with different input
%distributions


end

