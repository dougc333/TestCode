function [rows, cols] = randPointsInSquare(n)
%Generates n random points in a Square


end

