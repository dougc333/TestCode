function hullIndices = quickhull_recurse( sStart, sEnd, rows, cols, indices )
	nPoints = length(indices);

	% Base case
	if nPoints <= 1
		hullIndices = indices;
		return;
	end

	% Calculate direction perpendicular to the split line
	sVec = sEnd - sStart;
	sPerp = [sVec(2) (-sVec(1))];

	% Find the point with the greatest scaled, squared distance to the split-line
	% This is our "pivot" point
	bestDist = -1;	% Any negative value will do - distances will be all positive.
	pivotIdx = -1;
	for i = 1:nPoints
		idx = indices(i);
		pt = [rows(idx) cols(idx)];
		toPoint = pt - sStart;
		dist = abs( dot( sPerp, toPoint ) );
		if dist > bestDist
			bestDist = dist;
			pivotIdx = idx;
		end
	end

	% Split into the two halves
	pivotPt = [rows(pivotIdx) cols(pivotIdx)];
	indicesA = [];
	indicesB = [];

	for i = 1:nPoints
		idx = indices(i);
		if idx ~= pivotIdx
			pt = [rows(idx) cols(idx)];
			if which_side( sEnd, pivotPt, pt ) == 'r'
				indicesA = [indicesA idx];
			elseif which_side( pivotPt, sStart, pt ) == 'r'
				indicesB = [indicesB idx];
			end
		end
    end    

	% Recurse and re-combine
	hullIndicesA = quickhull_recurse( pivotPt, sEnd, rows, cols, indicesA );
	hullIndicesB = quickhull_recurse( sStart, pivotPt, rows, cols, indicesB );

	hullIndices = [hullIndicesA pivotIdx hullIndicesB];

