function b = ishull( rows, cols, hullIndices )
	nPoints = length(rows);
	for i = 1:length(hullIndices)
		iStart = hullIndices(i);

		iEnd = -1;
		if i == length(hullIndices)
			iEnd = hullIndices(1);
		else
			iEnd = hullIndices(i+1);
		end

		startPt = [rows(iStart) cols(iStart)];
		endPt = [rows(iEnd) cols(iEnd)];

		% now make sure every point is to this line's left, or co-linear
		for j = 1:nPoints
			pt = [rows(j) cols(j)];
			if which_side( startPt, endPt, pt ) == 'r'
				b = 0;
				return;
			end
		end
	end

	% Test last line
	b = 1;
