function [ pass, R, img ] = test_convex_hull( )
   pass = 0;

   fprintf('Testing 2D random walk matrices s = 10.\n');
   for i = 1:5
       fprintf('Performing test %d: ', i);
       img = random_2d_walk(10,10,50,3);
       P2 = convhull_indices_to_points(@convex_hull_giftwrapping, img);
       P1 = convhull_indices_to_points(@convhull, img);

       [res,diff] = compare_convex_hull(P1, P2);

       if (res == 0)
          fprintf('   Reference hull:\n');
          P1
          fprintf('   Student hull:\n');
          R = P2
          display_convex_hull(img, P1, P2, diff);
          pass = 0;
          return;
       end
   end

   fprintf('\nTesting 2D random walk matrices s = 100.\n');
   for i = 1:5
       fprintf('Performing test %d: ', i);
       img = random_2d_walk(100,100,1000,3);
       P2 = convhull_indices_to_points(@convex_hull_giftwrapping, img);
       P1 = convhull_indices_to_points(@convhull, img);

       [res,diff] = compare_convex_hull(P1, P2);

       if (res == 0)
          fprintf('   Reference hull:\n');
          P1
          fprintf('   Student hull:\n');
          R = P2
          display_convex_hull(img, P1, P2, diff);
          pass = 0;
          return;
       end
   end

   fprintf('\nTesting 2D random walk matrices s = 200.\n');
   for i = 1:5
       fprintf('Performing test %d: ', i);
       img = random_2d_walk(200,200,2500,3);
       P2 = convhull_indices_to_points(@convex_hull_giftwrapping, img);
       P1 = convhull_indices_to_points(@convhull, img);

       [res,diff] = compare_convex_hull(P1, P2);

       if (res == 0)
          fprintf('   Reference hull:\n');
          P1
          fprintf('   Student hull:\n');
          R = P2
          display_convex_hull(img, P1, P2, diff);
          pass = 0;
          return;
       end
   end

   fprintf('\nTesting normally-distributed sets s = 10, mu = 5, sigma = 3, c = 50.\n');
   for i = 1:5
       fprintf('Performing test %d: ', i);
       img = random_gaussian_distrib(50,10,10,5,3);
       P2 = convhull_indices_to_points(@convex_hull_giftwrapping, img);
       P1 = convhull_indices_to_points(@convhull, img);

       [res,diff] = compare_convex_hull(P1, P2);

       if (res == 0)
          fprintf('   Reference hull:\n');
          P1
          fprintf('   Student hull:\n');
          R = P2
          display_convex_hull(img, P1, P2, diff);
          pass = 0;
          return;
       end
   end

   fprintf('\nTesting normally-distributed sets s = 100, mu = 50, sigma = 15, c = 1000.\n');
   for i = 1:5
       fprintf('Performing test %d: ', i);
       img = random_gaussian_distrib(1000,100,100,50,15);
       P2 = convhull_indices_to_points(@convex_hull_giftwrapping, img);
       P1 = convhull_indices_to_points(@convhull, img);

       [res,diff] = compare_convex_hull(P1, P2);

       if (res == 0)
          fprintf('   Reference hull:\n');
          P1
          fprintf('   Student hull:\n');
          R = P2
          display_convex_hull(img, P1, P2, diff);
          pass = 0;
          return;
       end
   end

   fprintf('\nTesting normally-distributed sets s = 200, mu = 100, sigma = 50, c = 5000.\n');
   for i = 1:5
       fprintf('Performing test %d: ', i);
       img = random_gaussian_distrib(5000,200,200,100,50);
       P2 = convhull_indices_to_points(@convex_hull_giftwrapping, img);
       P1 = convhull_indices_to_points(@convhull, img);

       [res,diff] = compare_convex_hull(P1, P2);

       if (res == 0)
          fprintf('   Reference hull:\n');
          P1
          fprintf('   Student hull:\n');
          R = P2
          display_convex_hull(img, P1, P2, diff);
          pass = 0;
          return;
       end
   end


   pass = 1;
