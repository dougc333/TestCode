function [ out ] = display_convex_hull( img, P1, P2, diff)
  out = 1;
  
  [ptsx, ptsy] = find(img);
  
  plot(ptsx, ptsy, 'og', P1(:,2), P1(:,1), '-og', P2(:,2), P2(:,1), '-ob', diff(:,2), diff(:,1), '*r');
  
  return;