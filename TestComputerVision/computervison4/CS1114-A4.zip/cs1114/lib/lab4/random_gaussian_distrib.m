function [ out ] = random_gaussian_distrib(n, h, w, mu, sigma)
out = zeros(h,w);

for i = 1:n
       x = round(normrnd(mu,sigma));
       y = round(normrnd(mu,sigma));
       
       if (x < 1) 
           x = 1;
       end
       if (y < 1) 
           y = 1;
       end
       if (x > w) 
           x = w;
       end
       if (y > h) 
           y = h;
       end

       out(x,y) = 1;
end