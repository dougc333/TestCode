function plotConvexHull(rows, cols, hullIndices)

plot(cols, rows, '.', cols(hullIndices), rows(hullIndices), 'r-', 'Linewidth', 2);
