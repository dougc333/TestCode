function hullIndices = quickhull( rows, cols )
	nPoints = length(rows);

	% For the n=3 case, we still need to find the correct counter-clockwise order.
	% So, let the algorithm do that.
	if nPoints <= 2
		hullIndices = 1:nPoints;
		return;
	end

	% Find top and bottom rows
	[minRow topIdx] = min(rows);
	[maxRow botIdx] = max(rows);
	sStart = [rows(botIdx) cols(botIdx)];
	sEnd = [rows(topIdx) cols(topIdx)];

	% Split into two halves
	rightIndices = [];
	leftIndices = [];

	for idx = 1:nPoints
		if idx ~= topIdx && idx ~= botIdx
			pt = [rows(idx) cols(idx)];
			if which_side( sStart, sEnd, pt ) == 'r'
				rightIndices = [rightIndices idx];
			else
				leftIndices = [leftIndices idx];
			end
		end
	end

	% Recurse. Important to pass the split start/end in the correct counter-clockwise orientation
	rightHulls = quickhull_recurse( sEnd, sStart, rows, cols, rightIndices );
	leftHulls = quickhull_recurse( sStart, sEnd, rows, cols, leftIndices );

	hullIndices = [botIdx rightHulls topIdx leftHulls];
