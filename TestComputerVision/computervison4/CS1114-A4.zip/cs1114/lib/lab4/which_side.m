function side = which_side( lineStart, lineEnd, pt )
	dir = [(lineEnd - lineStart) 0];
	toPt = [(pt - lineStart) 0];
	product = cross( dir, toPt );
	if product(3) > 0
		% left
		side = 'l';
	elseif product(3) == 0
		% co-linear
		side = 'c';
	else
		% right
		side = 'r';
	end
