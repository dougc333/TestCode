function [ isleft ] = test_leftness( x0, y0, x1, y1, x2, y2 )
%TEST_LEFTNESS Checks to see if a point is left of a line
%
%   ARGS: 
%       x0, y0, x1, y1, x2, y2: (x0, y0) and (x1, y1) are two points that
%           define a line, and (x2, y2) is a third point
%
%   RETURN:
%       isleft: 1 if (x2, y2) lies to the left of the line determined by
%           (x0, y0) and (x1, y1), -1 if to the right, and 0 if all three 
%           points are colinear.

v = (x1 - x0)*(y2 - y0) - (x2 - x0)*(y1 - y0);
isleft = (v < 0) - (v > 0);