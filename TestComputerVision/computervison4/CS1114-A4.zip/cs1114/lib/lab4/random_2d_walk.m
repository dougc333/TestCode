function [ out ] = random_2d_walk( w, h, steps, shoesize )
  x = round(h/2);
  y = round(h/2);
  
  out = zeros(h,w);
  
  if (shoesize < 1)
      shoesize = 1;
  end
  if (shoesize > x - 1)
      shoesize = x - 1;
  end
  if (shoesize > y - 1)
      shoesize = y - 1;
  end
  
  for i = 1:steps
     x = x + round(unifrnd(-1,1));
     y = y + round(unifrnd(-1,1));
     
     if (x < shoesize)
         x = shoesize;
     end
     if (x > w + 1 - shoesize)
         x = w + 1 - shoesize;
     end
     if (y < shoesize)
         y = shoesize;
     end
     if (y > h + 1 - shoesize)
         y = h + 1 - shoesize;
     end
     
     for sx = (x-shoesize+1):(x+shoesize-1)
         for sy = (y-shoesize+1):(y+shoesize-1)
             out(sy,sx) = 1;
         end
     end
  end
  
  return;