function [ P ] = cs100r_convhull(img)
if(img == 0)
    P = 0;
else
    [r,c] = find(img);
    K = convhull(c,r);

    xcoords = c(K);
    ycoords = r(K);

    P = [xcoords ycoords];
end