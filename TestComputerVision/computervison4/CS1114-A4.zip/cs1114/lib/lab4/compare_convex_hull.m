function [ret, diff] = compare_convex_hull(P1, P2)
    % P1 is ref, P2 is student
    
    ret = 0;
    
    [p1len,dummy] = size(P1);
    [p2len,dummy] = size(P2);
    
    if (p1len ~= p2len)
        if (P2(p2len,1) ~= P2(1,1) | P2(p2len,2) ~= P2(p2len,2))
            fprintf('[FAIL]\n   ERR: Student hull not connected (first point and last point differ).\n');
            diff = P2;
            return;
        end
    end

    P1segs = points_to_segs(P1);
    P2segs = points_to_segs(P2);
    P2segs_rev = points_to_segs(flipud(P2));
    
    P1segs = remove_colinear_segs(P1segs);
    P2segs = remove_colinear_segs(P2segs);
    P2segs_rev = remove_colinear_segs(P2segs_rev);
       
    diff_fwd_12 = setdiff(P1segs, P2segs, 'rows');
    diff_rev_12 = setdiff(P1segs, P2segs_rev, 'rows');
    diff_fwd_21 = setdiff(P2segs, P1segs, 'rows');
    diff_rev_21 = setdiff(P2segs_rev, P1segs, 'rows');
    
    [diff_cnt_fwd_12 dummy] = size(diff_fwd_12);
    [diff_cnt_rev_12 dummy] = size(diff_rev_12);
    [diff_cnt_fwd_21 dummy] = size(diff_fwd_21);
    [diff_cnt_rev_21 dummy] = size(diff_rev_21);

    diff_cnt_fwd = diff_cnt_fwd_12 + diff_cnt_fwd_21;
    diff_cnt_rev = diff_cnt_rev_12 + diff_cnt_rev_21;
    
    if (diff_cnt_fwd == 0)
        fprintf('[PASS]\n');
        diff = 0;
        ret = 1;
    elseif (diff_cnt_rev == 0)
        fprintf('[PASS]\n    INFO: student hull orientation is reversed.\n');
        diff = 0;
        ret = 1;
    else
        fprintf('[FAIL]\n');
        if (diff_cnt_fwd < diff_cnt_rev | diff_cnt_fwd == diff_cnt_rev)
            if (diff_cnt_fwd_12 > 0) 
                fprintf('    ERR: Student hull does not contain these segments:\n');
                diff_fwd_12
            end
            if (diff_cnt_fwd_21 > 0)
                fprintf('    ERR: student hull contains these extra segments:\n');
                diff_fwd_21
            end
            diff = unique([reshape(diff_fwd_12',2,[])'; reshape(diff_fwd_21',2,[])'], 'rows');
        else
            fprintf('    INFO: student hull orientation is reversed.\n');
            if (diff_cnt_fwd_12 > 0) 
                fprintf('    ERR: student hull does not contain these segments:\n');
                diff_fwd_12
            end
            if (diff_cnt_fwd_21 > 0)
                fprintf('    ERR: student hull contains these extra segments:\n');
                diff_fwd_21
            end            
            diff = unique([reshape(diff_fwd_12',2,[])'; reshape(diff_fwd_21',2,[])'], 'rows');
        end
    end
    
    return;