function [ segs ] = points_to_segs( pts )
    [numpts,dummy] = size(pts);
    
    segs = zeros(floor(numpts/2), 4);
    
    for i = 1:numpts-1
        segs(i,:) = [pts(i,1) pts(i,2) pts(i+1,1) pts(i+1,2)];
    end
    
    