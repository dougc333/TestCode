function [ P ] = cs100r_convhull(convhull_func, img)
if(img == 0)
    P = 0;
else
    [r,c] = find(img);
    K = convhull_func(c,r);

    xcoords = c(K);
    ycoords = r(K);

    P = [xcoords ycoords];
end
