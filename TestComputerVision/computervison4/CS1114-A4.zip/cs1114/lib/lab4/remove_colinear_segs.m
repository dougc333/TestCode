function [ out ] = remove_colinear_segs( segs )
    pts = [reshape(segs',2,[])'];
    [len,dummy] = size(pts);
        
    lastP2 = [pts(1,:)];
      
    ret = [lastP2];
    
    for i = 3:2:len-1
%          [lastP2;
%           pts(i,:);
%           pts(i+1,:)]
     
        if (test_leftness(lastP2(1), lastP2(2), pts(i,1), pts(i,2), pts(i+1,1), pts(i+1,2)) ~= 0)
            ret = [ret; [pts(i,1) pts(i,2)]];            
        else
            fprintf('[%d %d] ', pts(i,1), pts(i,2))
        end
        
        lastP2 = pts(i,:);
    end
    
    ret = [ret; pts(len,:)];
    
    out = points_to_segs(ret);
    
    return;