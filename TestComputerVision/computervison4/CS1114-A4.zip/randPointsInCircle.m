function [rows, cols] = randPointsInCircle(n)
%Generates n random points in a Circle


end

