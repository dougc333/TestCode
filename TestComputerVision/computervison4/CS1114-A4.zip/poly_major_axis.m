function  M  = poly_major_axis(rows, cols)
%This function takes as inputs a list of row values and a list of column
%values, and outputs a 2 x 2 matrix M with the points that for the major
%axis


end

