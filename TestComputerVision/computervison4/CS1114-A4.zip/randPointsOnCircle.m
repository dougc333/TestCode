function [rows, cols] = randPointsOnCircle(n)
%Generates n random points on a Circle


end

