function theta = lightstick_orientation( bimage )
%takes in a binary image of the lightstick and returns the orientation
%relative to the vertical, based on angle.
end

