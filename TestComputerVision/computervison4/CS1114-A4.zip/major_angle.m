function theta = major_angle( M )
%This function takes a matrix M of the form of the output of poly_major_
%axis, representing the two points that define the major axis, and finds 
%the angle relative to the vertical  


end

