function [rows, cols] = find_image_boundary( bimage )
%Finds the points on an image boundary and returns their coordinates in
%arrays rows and cols. No more than one line, or two if filter matrix
%created on seperate line.


end

