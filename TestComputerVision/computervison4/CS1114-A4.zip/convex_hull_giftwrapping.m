function hullIndices = convex_hull_giftwrapping(rows,cols)
%Takes as input a list of row values and a list of column values and
%outputs the indices of point in the convex hull, refering to the input
%lists
%TODO: Implement

end