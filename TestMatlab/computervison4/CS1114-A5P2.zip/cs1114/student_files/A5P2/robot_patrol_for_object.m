function robot_patrol_for_object(image)
% Given the provided image, the robot will patrol the room looking for that object.
%
% Your code goes here.  Good luck!
