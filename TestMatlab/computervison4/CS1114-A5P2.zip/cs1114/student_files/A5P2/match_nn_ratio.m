function matches = match_nn_ratio(descs1, descs2)
% Return a set of matches by finding the nearest neighbors of all 
% descriptors in descs1 in descs2.  This time, however, you will fill in 
% the distance as the ratio of the distance to the first nearest neighbor
% to the distance to the second nearest neighbor.
%
% On output, matches will be a 3-by-(num cols in descs1) matrix where each 
% column has an index of a descriptor in descs1, the index of the nearest 
% neighbor in descs2, and the distance between them.
