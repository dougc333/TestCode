function draw_transformed_object(canvas, template, T)
% Draw the outline of the transformed image 'template' on the canvas.
% We have a silly version below -- replace this with your code.

plot(canvas, [1 1]', [1 100]', 'r', 'LineWidth', 4);
plot(canvas, [1 100]', [100 100]', 'r', 'LineWidth', 4);
plot(canvas, [100 100]', [100 1]', 'r', 'LineWidth', 4);
plot(canvas, [100 1]', [1 1]', 'r', 'LineWidth', 4);
