function matches_out = threshold_matches(matches_in, threshold)
% Return all matches whose distances are below a threshold
%
% = Inputs =
%   matches_in:  input matches, as a 3xN matrix (where N = # of matches); 
%                each column of this matrix contains 3 entries: an index
%                into the features of image 1, an index into the features
%                of image 2, and the computed distance
%   threshold:   the distance threshold; all features with distances larger
%                than this threshold should be discarded
%
% = Outputs =
%   matches_out: a 3xM matrix, whose columns are the subset of matches_in
%                that survive the thresholding
%
% Note that it should be possible to implement this with one line of code.
