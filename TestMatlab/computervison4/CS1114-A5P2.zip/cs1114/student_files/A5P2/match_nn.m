function matches = match_nn(descs1, descs2)
% Return a set of matches by finding the nearest neighbors of all 
% descriptors in descs1 in descs2.
%
% On output, matches will be a 3-by-(num cols in descs1) matrix where each 
% column has an index of a descriptor in descs1, the index of the nearest 
% neighbor in descs2, and the distance between them.

