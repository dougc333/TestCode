function T = fit_affine_transform(P, Q)
% Compute a 2D (homogeneous) affine transformation from 3 point matches, by
% solving a linear system.
% P and Q are 2x3 matrices storing matching features in image 1 and image 2
% respectively.
%
% = Inputs =
%    P, Q: each column of P is a feature location in image 1
%          each column of Q is a corresponding feature location in image 2
%
% = Output =
%    T:    a 3x3 affine transformation mapping the points in P to the
%    corresponding points in Q

