function [ out ] = snailsort( A )
%SNAILSORT Sort an array, in as slow a manner as possible.

done = 0; n = length(A); 

while (done == 0)
    p = randperm(n);
    A = A(p);
    if issorted(A)
        out = A;
        done = 1;
    end
end
