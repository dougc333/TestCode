function [A1, A2, A3] = partition_array(A, pivot)
%PARTITION_ARRAY Partitions an array A into elements smaller than, 
%  equal to, or larger than the pivot into output arrays A1, A2, and A3. 
