function s = quickselect(A, k)
% Select an element from an array using quickselect
