function [ S ] = quicksort(A)
% Sorts an array using quicksort
