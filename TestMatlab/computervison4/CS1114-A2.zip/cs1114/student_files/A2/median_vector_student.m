function [median_row, median_col] = median_vector_student(nonzero_rows, nonzero_cols)
% Implement median_vector_student here
