function x = randomint(n)
% Returns a random integer from 1 to n
x = randint(1,1,n)+1;
