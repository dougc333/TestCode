function [centroid_row, centroid_col] = centroid(nonzero_rows, nonzero_cols)
