function [ top_row, bottom_row, left_col, right_col ] = dense_box_student( bimage )
