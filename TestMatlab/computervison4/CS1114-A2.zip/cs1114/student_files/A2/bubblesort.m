function A = bubblesort(A)
% Sort an array using bubblesort
