function [rv_sum] = isum_student(in_vect)
