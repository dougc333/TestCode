function [rv_mean] = imean_student(in_vect)
