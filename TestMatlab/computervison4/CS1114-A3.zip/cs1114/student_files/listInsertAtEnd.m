function list = listInsertAtEnd(list, row, col)
% Insert an element x at the end of the list, and return the new list

% TODO: Implement this function
