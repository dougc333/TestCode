function [row, col, queue] = dequeue(queue)
% Get the front element from the queue and remove it

% TODO: Implement this function
