function labeled = CC_BFS_student(bimage, root_row, root_col, label, labeled)
% Run BFS to label a single connected component of an image.  When this
% function is finished, the matrix 'labeled' should have the value 'label'
% for every pixel that is in the same component of bimage as the pixel at 
% (root_row, root_col).
%
% Inputs: 
%    bimage: the thresholded binary image
%    root_row, root_col: the row and column of the root node
%    label:   the label that every pixel in this component should be given
%
% Outputs:
%    labeled: the matrix that should be properly labeled on exit

[num_rows, num_cols] = size(bimage);

% TODO: Implement the rest of this function
