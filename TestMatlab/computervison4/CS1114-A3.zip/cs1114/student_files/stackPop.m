function [row, col, stack] = stackPop(stack)
% Get the last element from the stack and remove it

% TODO: Implement this function
