function queue = enqueue(queue, row, col)
% Add an element to the back of the queue

% TODO: Implement this function
