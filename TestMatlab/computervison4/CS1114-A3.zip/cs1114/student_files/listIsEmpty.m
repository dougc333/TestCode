function empty = listIsEmpty(list)
% Return 1 if a list is empty, 0 otherwise

% TODO: Implement this function
