function list = listDeleteAtEnd(list)
% Delete the last element of a linked list

% TODO: Implement this function
