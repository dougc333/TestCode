function printLinkedList(list)
% Prints a linked list from start to end

% TODO: Implement this function
