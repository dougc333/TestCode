function stack = stackPush(stack, row, col)
% Push an element onto the stack

% TODO: Implement this function
