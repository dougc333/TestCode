function testStack()
% Test stack functionality

stack = newLinkedList();

stack = stackPush(stack, 10, 20);
stack = stackPush(stack, 20, 30);

[row, col, stack] = stackPop(stack);
fprintf('[%d, %d]\n', row, col);
[row, col, stack] = stackPop(stack);
fprintf('[%d, %d]\n', row, col);

stack = stackPush(stack, 40, 50);
stack = stackPush(stack, 60, 70);
[row, col, stack] = stackPop(stack);
stack = stackPush(stack, 80, 90);
[row, col, stack] = stackPop(stack);
fprintf('[%d, %d]\n', row, col);
[row, col, stack] = stackPop(stack);
fprintf('[%d, %d]\n', row, col);
