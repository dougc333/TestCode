function testLinkedList()
% Test that the linked list functions are working

list = newLinkedList();

list = listInsertAtStart(list, 10, 20);
list = listInsertAtEnd(list, 30, 40);
list = listInsertAtStart(list, 50, 60);
list = listDeleteAtEnd(list);
list = listDeleteAtStart(list);
list = listDeleteAtStart(list);
list = listInsertAtEnd(list, 70, 80);
list = listInsertAtEnd(list, 90, 100);
list = listInsertAtStart(list, 100, 110);
list = listDeleteAtEnd(list);
list = listDeleteAtStart(list);
list = listDeleteAtEnd(list);
list = listInsertAtStart(list, 120, 130);
list = listInsertAtStart(list, 140, 150);
list = listInsertAtStart(list, 160, 170);
list = listDeleteAtStart(list);
list = listInsertAtStart(list, 180, 190);

printLinkedList(list);
