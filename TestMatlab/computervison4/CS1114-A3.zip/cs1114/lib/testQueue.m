function testQueue()
% Test stack functionality

queue = newLinkedList();

queue = enqueue(queue, 10, 20);
queue = enqueue(queue, 20, 30);

[row, col, queue] = dequeue(queue);
fprintf('[%d, %d]\n', row, col);
[row, col, queue] = dequeue(queue);
fprintf('[%d, %d]\n', row, col);

queue = enqueue(queue, 40, 50);
queue = enqueue(queue, 60, 70);
[row, col, queue] = dequeue(queue);
queue = enqueue(queue, 80, 90);
[row, col, queue] = dequeue(queue);
fprintf('[%d, %d]\n', row, col);
[row, col, queue] = dequeue(queue);
fprintf('[%d, %d]\n', row, col);
