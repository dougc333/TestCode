function [index, list] = getNewListCell(list)
% Returns the index of a new list cell

% Scan the list for the new free index
free = list(4);
n = length(list);

index = free;
list(4) = list(4) + 4;

if list(4) > n
    error('Linked list is out of memory\n');
end
