function [ labeled, num_components ] = CC_DFS(bimage)
% Compute an image 'labeled' where every pixel is labeled with the
% connected component it is in, and return the number of components

[labeled, num_components] = CC(bimage, 'DFS');
