function [ out_img ] = threshold_student(in_img, red_threshold, ...
green_threshold, blue_threshold)
 % This function creates an output image which is thresholded by the three
 % values in red_threshold, green_threshold, and blue_threshold.

