function output = dilateNTimes(input,n)
% Repeatedly dilate an image (n times), returning the result in an image
% called 'output'.  This function should call 'dilateImage'.
